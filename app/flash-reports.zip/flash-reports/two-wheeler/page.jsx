import React from 'react'
import TwoWheeler from '../components/categories/TwoWheeler'

const page = () => {
  return (
    <TwoWheeler/>
  )
}

export default page