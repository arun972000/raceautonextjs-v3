import React from 'react'
import OverAll from './components/categories/OverAll'

const page = () => {
    return (
        <OverAll />
    )
}

export default page