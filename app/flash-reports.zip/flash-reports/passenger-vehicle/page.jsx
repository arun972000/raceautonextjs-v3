import React from 'react'
import TwoWheeler from '../components/categories/PassengerVehicleOEM'

const page = () => {
  return (
    <TwoWheeler/>
  )
}

export default page