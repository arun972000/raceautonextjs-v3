export const dynamic = "force-dynamic";
import React from 'react'
import CommercialVehicle from '../components/categories/CommercialVehicle'

const page = () => {
    return (
        <CommercialVehicle />
    )
}

export default page