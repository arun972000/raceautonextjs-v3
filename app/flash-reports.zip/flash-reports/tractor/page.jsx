import React from 'react'
import TractorOEM from '../components/categories/TractorOEM'

const page = () => {
  return (
    <TractorOEM/>
  )
}

export default page