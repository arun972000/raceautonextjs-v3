import React from 'react'
import ThreeWheeler from '../components/categories/ThreeWheeler'

const page = () => {
  return (
    <ThreeWheeler/>
  )
}

export default page